full-stop cafe — rig bundle

spec.json         Every character's full RigSpec. Load this back with
                  「导入存档」 in the rig tuner (press ` in game).
profiles.ts.txt   The same specs formatted for pasting into
                  src/actors/profiles/index.ts.
textures/*.png    Painted piece textures, one per texture id. The filename
                  is the id with ':' replaced by '__'.

To make an edit permanent in the repository, paste the blocks from
profiles.ts.txt over the matching spec in profiles/index.ts. Painted
textures are referenced by id, so they need to be loaded from a bundle or
kept in localStorage — or exported as PNGs into src/assets/hair/ and
re-pointed at from the texture dropdown.
